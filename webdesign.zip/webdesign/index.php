<html>
<head>
<title>Redirect to Landing Page</title>
<script type="text/javascript">
window.location = "landing";
</script>
<head>
<body>Redirect</body>
</html>