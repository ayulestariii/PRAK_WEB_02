
<!DOCTYPE html>
<html lang="en">
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Boostgram SMM Panel merupakan website/situs penyedia jasa layanan social media marketing untuk reseller panel. SMM Panel terbaik di Indonesia. Pusat Reseller SMM Panel di Indonesia.">
		<meta name="keywords" content="boostgram, smm panel, smm panel indonesia">
		<meta name="author" content="Penulis Kode">
		<link rel="shortcut icon" href="https://boostgram.id/assets/favicon-custom.png">
		<title>Boostgram.id SMM Panel - SMM Panel Indonesia Terbaik - SMM Panel Indonesia Termurah</title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/simpletextrotator.css">
		<link href="css/style.css" rel="stylesheet">
		<style type="text/css">.bg-img { background: url('https://boostgram.id/assets/header-custom.jpg') center center; background-repeat: no-repeat; background-size: cover; }</style>
		<!-- font awesome -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
        <link href="css/icons.css" rel="stylesheet">
        <link href="css/icons-social.css" rel="stylesheet">
		<script src="js/jquery.min.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-85612760-2');
</script>
 
	</head>
	<body>
<script></script> 
		<nav class="navbar navbar-expand-lg fixed-top navbar-custom navbar-default navbar-light navbar-custom-dark bg-trans sticky">
			<div class="container">
				<a class="navbar-brand logo" href="https://boostgram.id/">
					<span class="logo logo-white" style="color: #fff">Boostgram.id SMM Panel</span>
					<span class="logo logo-dark" style="color: #000">Boostgram.id SMM Panel</span>
					<!--
					<img src="images/logo_white.png" class="logo logo-white" alt="logo">
					<img src="images/logo.png" class="logo logo-dark" alt="logo">
					-->
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarCollapse">
					<ul class="nav navbar-nav ml-auto navbar-center" id="mySidenav">
						<li class="nav-item">
							<a href="https://boostgram.id/" class="nav-link">Halaman Utama</a>
						</li>
						<li class="nav-item">
							<a href="https://boostgram.id/page/services" class="nav-link">Daftar Layanan</a>
						</li>
						<li class="nav-item">
							<a href="https://boostgram.id/auth/login" class="nav-link">Masuk</a>
						</li>
						<li class="nav-item">
							<a href="https://boostgram.id/auth/register" class="nav-link">Daftar</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		<section class="section-lg home-alt bg-img" id="home">
			<div class="bg-overlay-gradient bg-overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-lg-8 offset-lg-2">
						<div class="home-wrapper text-center">
							<h1 class="mb-0">Boostgram.id SMM Panel</h1>
							<div class="h2 my-5 text-light"><span class="typed" data-elements="SMM Panel terbaik di Indonesia,Pusat Reseller SMM Panel di Indonesia,SMM Panel Indonesia termurah"></span></div>
							<a href="https://boostgram.id/auth/login" class="btn btn-custom"><i class="fa fa-sign-in-alt fa-fw mr-1"></i> Masuk</a>
							<a href="https://boostgram.id/auth/register" class="btn btn-dark ml-2"><i class="fa fa-user-plus fa-fw mr-1"></i> Daftar</a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section>
			<div class="container">
				<div class="row">
					<div class="col-lg-8 offset-lg-2">
						<div class="facts-box text-center">
							<div class="row">
								<div class="col-md py-3">
									<span class="h2">20.501+</span>
									<p class="text-muted mt-2 mb-0">Pengguna Aktif</p>
								</div>
								<div class="col-md py-3">
									<span class="h2">1.578.991+</span>
									<p class="text-muted mt-2 mb-0">Pesanan Dikerjakan</p>
								</div>
								<div class="col-md py-3">
									<span class="h2">118+</span>
									<p class="text-muted mt-2 mb-0">Layanan</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
        
        <div class="clearfix"></div>

        <section class="section" id="features">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-credit"></i></div>
                            <h3>Pembayaran Otomatis</h3>
                            <p class="text-muted">Deposit saldo dapat diverifikasi otomatis tanpa harus konfirmasi pembayaran.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-repeat"></i></div>
                            <h3>Pembaruan</h3>
                            <p class="text-muted">Layanan selalu diperbarui agar lebih ditingkatkan dan memberi Anda pengalaman terbaik.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-refresh-cloud"></i></div>
                            <h3>Proses Otomatis</h3>
                            <p class="text-muted">Setelah anda melakukan order, secara otomatis server akan memproses pesanan anda.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-science"></i></div>
                            <h3>Layanan Berkualitas</h3>
                            <p class="text-muted">Kami menyediakan berbagai layanan terbaik untuk kebutuhan Sosial Media & Pulsa Untuk Anda.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-light"></i></div>
                            <h3>Pelayanan Bantuan</h3>
                            <p class="text-muted">Kami siap membantu Anda jika Anda mengalami kesulitan atau tidak mengerti terkait layanan yang kami sediakan.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-display1"></i></div>
                            <h3>Desain Clean & Responsive</h3>
                            <p class="text-muted">Website kami dapat diakses melalui berbagai device/perangkat baik PC, tablet, maupun mobile phone.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="section" style="padding-top: 0 !important " id="produk">
			<div class="container">
				<div class="row">
					<div class="col-12">
        <h4 class="text-center mt-4 mb-3">Token Listrik</h4>
						<div class="table-responsive">
							<table class="table table-bordered table-hover table-striped">
								<thead class="thead-dark">
									<tr>
										<th colspan="5">PLN</th>
									</tr>
								</thead>
								<thead>
									<tr>
										<th>Paket</th>
										<th>Harga</th>
										<th>Waktu</th>
										<th>S&K</th>
										<th>Deskripsi</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>XTRA COMBO 99GB + 99GB</td>
										<td>99.000 RIBU</td>
										<td>IDR 21.040</td>
										<td>IDR 20.540</td>
										<td>Hanya Membutuhkan Nomor HP</span></td>
									</tr>
									<tr>
										<td>PLN50</td>
										<td>PLN 50.000</td>
										<td>IDR 51.050</td>
										<td>IDR 50.550</td>
										<td><span class="badge badge-success">Aktif</span></td>
									</tr>
									<tr>
										<td>PLN100</td>
										<td>PLN 100.000</td>
										<td>IDR 101.050</td>
										<td>IDR 100.550</td>
										<td><span class="badge badge-success">Aktif</span></td>
									</tr>
									<tr>
										<td>PLN200</td>
										<td>PLN 200.000</td>
										<td>IDR 201.050</td>
										<td>IDR 200.550</td>
										<td><span class="badge badge-success">Aktif</span></td>
									</tr>
									<tr>
										<td>PLN500</td>
										<td>PLN 500.000</td>
										<td>IDR 501.050</td>
										<td>IDR 500.550</td>
										<td><span class="badge badge-success">Aktif</span></td>
									</tr>
									<tr>
										<td>PLN1000</td>
										<td>PLN 1.000.000</td>
										<td>IDR 1.001.050</td>
										<td>IDR 1.000.550</td>
										<td><span class="badge badge-success">Aktif</span></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>

        <section class="section" id="faqs">
            <div class="container">
                <div class="row text-center">
                    <div class="col-sm-12">
                        <h2 class="title">Pertanyaan Umum</h2>
                        <p class="title-alt">Berikut telah kami rangkum beberapa pertanyaan yang sering ditanyakan client terkait layanan kami.</p>
                        <div class="row text-left">
                            <div class="col-sm-6">
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>Apa Itu ansyari-pedia.com?</h4>
                                    <p><span><b>A. </b></span>ansyari-pedia.com adalah sebuah platform bisnis yang menyediakan berbagai layanan isi ulang ponsel dan social media marketing yang bergerak terutama di Indonesia. Dengan bergabung bersama kami, Anda dapat menjual produk isi ulang seperti pulsa, paket data, voucher game, e-money.dsb serta menjadi penyedia jasa social media seperti jasa penambah Followers, Likes, dll.</p>
                                </div>
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>Bagaimana Cara Mendaftar di ansyari-pedia.com?</h4>
                                    <p><span><b>A. </b></span>Silahkan kamu klik form Pendaftaran yang sudah tertera diatas.</p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>Bagaimana Cara Melakukan Deposit/Isi Saldo?</h4>
                                    <p><span><b>A. </b></span>Untuk melakukan deposit/isi saldo, Anda hanya perlu masuk terlebih dahulu ke akun Anda dan menuju halaman deposit dengan mengklik menu yang sudah tersedia. Kami menyediakan deposit melalui bank dan pulsa.</p>
                                </div>
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>Bagaimana Cara Membuat Pesanan?</h4>
                                    <p><span><b>A. </b></span>Untuk membuat pesanan sangatlah mudah, Anda hanya perlu masuk terlebih dahulu ke akun Anda dan menuju halaman pemesanan dengan mengklik menu yang sudah tersedia. Selain itu Anda juga dapat melakukan pemesanan melalui request API.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <footer class="footer bg-dark">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 text-center">
                        <p class="copyright">
                            � 2020                            <a href="https://ansyari-pedia.com/">
                                <b>ansyari-pedia.com</b>
                            </a>.</p>
                    </div>
                </div>
            </div>
        </footer>

        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/easing.min.js" type="text/javascript"></script>

        <script src="js/typed.js" type="text/javascript"></script>

        <script src="js/jquery.app.js" type="text/javascript"></script>
        <script>
            /* ==============================================
            //Typed
            =============================================== */
            $(".typed").each(function(){
                var $this = $(this);
                $this.typed({
                strings: $this.attr('data-elements').split(','),
                typeSpeed: 100, // typing speed
                backDelay: 3000 // pause before backspacing
                });
            });
        </script>

</html>