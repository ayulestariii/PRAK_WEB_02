
<!DOCTYPE html>
<html lang="en">
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Boostgram SMM Panel merupakan website/situs penyedia jasa layanan social media marketing untuk reseller panel. SMM Panel terbaik di Indonesia. Pusat Reseller SMM Panel di Indonesia.">
		<meta name="keywords" content="boostgram, smm panel, smm panel indonesia">
		<meta name="author" content="Penulis Kode">
		<link rel="shortcut icon" href="../assets/favicon-custom.png">
		<title>Ay SMM SMM Panel</title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/simpletextrotator.css">
		<link href="css/blue.css" rel="stylesheet">
		<style type="text/css">.bg-img { background: url('../assets/header-custom.jpg') center center; background-repeat: no-repeat; background-size: cover; }</style>
		<!-- font awesome -->
		<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
		<script src="js/jquery.min.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-85612760-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-85612760-2');
</script>
 
	</head>
	<body>
<script></script> 
		<nav class="navbar navbar-expand-lg fixed-top navbar-custom navbar-default navbar-light navbar-custom-dark bg-trans sticky">
			<div class="container">
				<a class="navbar-brand logo" href="index.php">
					<span class="logo logo-white" style="color: #fff">Ay SMM SMM Panel</span>
					<span class="logo logo-dark" style="color: #000">Ay SMM SMM Panel</span>
					<!--
					<img src="images/logo_white.png" class="logo logo-white" alt="logo">
					<img src="images/logo.png" class="logo logo-dark" alt="logo">
					-->
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarCollapse">
					<ul class="nav navbar-nav ml-auto navbar-center" id="mySidenav">
						<li class="nav-item">
							<a href="index.php" class="nav-link">Halaman Utama</a>
						</li>
						<li class="nav-item">
							<a href="service.php" class="nav-link">Daftar Layanan</a>
                        </li>
					</ul>
				</div>
			</div>
		</nav>
<section class="section-md home-alt bg-img">
	<div class="bg-overlay-gradient bg-overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-12 text-center">
				<h1>Daftar Cabang</h1>
			</div>
		</div>
	</div>
</section>
<section class="section">
	<div class="container">
<div class="row">
	<div class="col-12">
		<div class="card shadow">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold"><i class="fas fa-fw fa-list mr-2"></i> Daftar Cabang</h6>
			</div>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th colspan="6" class="table-primary"> </th>
							</tr>
							<tr>
								<th>ID</th>
								<th>NAMA PROVINSI/KABUPATEN</th>
								<th>NOMOR TELEPON</th>
								<th>EMAIL</th>
								<th>ALAMAT LENGKAP</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>1</td>
								<td>PROVINSI BANTEN</td>
								<td>021 XXX XXX</td>
								<td>provinsi.banten@aysmm.co.id</td>
								<td>Banten, Serang, Serang, Banten, Indonesia, -</td>
							</tr>
							<tr>
								<td>2</td>
								<td>PROVINSO BANGKA BELITUNG</td>
								<td>021 XXX XXX</td>
								<td>provinsi.bangkabelitung@aysmm.co.id</td>
								<td>Jl. Pilau Bangka Komplek Perkantoran Gubernur<br>samping Asrama Haji Desa Padang Baru, <br>Kec. Pengkalan Baru Kab. Bangka Tengah Prov Bangka Belitung. <br>Bakam, Bangka, Bangka Belitung, Indonesia, -</td>
							</tr>
							<tr>
								<td>3</td>
								<td>PROVINSI DKI JAKARTA</td>
								<td>021 XXX XXX</td>
								<td>provinsi.dkijakarta@ayysmm.com</td>
								<td>Jl . Cikajang No 60 Kel. Petogogan<br>Kec. Kebayoran Baru Jak Sel, Cengkareng, <br>Jakarta Barat, DKI Jakarta, Indonesia, -</td>
							</tr>
							<tr>
								<td colspan="6" align="center"><br><br>Nama nama di atas hanyalah contoh. Mohon Maaf jika ada salah penyebutan tempat dll.</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>	</div>
		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/scrollspy.min.js"></script>
		<script src="js/jquery.easing.min.js"></script>
		<script src="js/typed.js"></script>
		<script src="js/jquery.app.js"></script>
		<script>
			$(window).scroll(function() {
				var scroll = $(window).scrollTop();
				if (scroll >= 50) {
					$(".sticky").addClass("is-sticky");
				} else {
					$(".sticky").removeClass("is-sticky");
				}
			});
			$(document).ready(function() {
				$(".typed").each(function() {
					var $this = $(this);
					$this.typed({
						strings: $this.attr('data-elements').split(','),
						typeSpeed: 100, // typing speed
						backDelay: 3000 // pause before backspacing
					});
				});
			});
        </script>
	</body>
</html>