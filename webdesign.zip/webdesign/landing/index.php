
<!DOCTYPE html>
<html lang="en">
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Boostgram SMM Panel merupakan website/situs penyedia jasa layanan social media marketing untuk reseller panel. SMM Panel terbaik di Indonesia. Pusat Reseller SMM Panel di Indonesia.">
		<meta name="keywords" content="boostgram, smm panel, smm panel indonesia">
		<meta name="author" content="Penulis Kode">
		<link rel="shortcut icon" href="../assets/user.png">
		<title>Ay SMM Panel - SMM Panel Indonesia Terbaik - SMM Panel Indonesia Termurah</title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/simpletextrotator.css">
        <link href="css/icons.css" rel="stylesheet">
        <link href="css/icons-social.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<style type="text/css">.bg-img { background: url('../assets/header-custom.jpg') center center; background-repeat: no-repeat; background-size: cover; }</style>
		<!-- font awesome -->
		<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
		<script src="js/jquery.min.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-85612760-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-85612760-2');
</script>
 
	</head>
	<body>
<script></script> 
		<nav class="navbar navbar-expand-lg fixed-top navbar-custom navbar-default navbar-light navbar-custom-dark bg-trans sticky">
			<div class="container">
				<a class="navbar-brand logo" href="index.php">
					<span class="logo logo-white" style="color: #fff">Ay SMM Panel</span>
					<span class="logo logo-dark" style="color: #000">Ay SMM Panel</span>
					<!--
					<img src="images/logo_white.png" class="logo logo-white" alt="logo">
					<img src="images/logo.png" class="logo logo-dark" alt="logo">
					-->
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarCollapse">
					<ul class="nav navbar-nav ml-auto navbar-center" id="mySidenav">
						<li class="nav-item">
							<a href="#home" class="nav-link">Halaman Utama</a>
						</li>
						<li class="nav-item">
							<a href="cabang.php" class="nav-link">Cabang</a>
						</li>
						<li class="nav-item">
							<a href="#produk" class="nav-link">Layanan</a>
						</li>
						<li class="nav-item">
							<a href="#faqs" class="nav-link">Pertanyaan Umum</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		<section class="section-lg home-alt bg-img" id="home">
			<div class="bg-overlay-gradient bg-overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-lg-8 offset-lg-2">
						<div class="home-wrapper text-center">
							<h1 class="mb-0">Ay SMM Panel</h1>
							<div class="h2 my-5 text-light"><span class="typed" data-elements="SMM Panel terbaik di Indonesia,Pusat Reseller SMM Panel di Indonesia,SMM Panel Indonesia termurah"></span></div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section>
			<div class="container">
				<div class="row">
					<div class="col-lg-8 offset-lg-2">
						<div class="facts-box text-center">
							<div class="row">
								<div class="col-md py-3">
									<span class="h2">20.501+</span>
									<p class="text-muted mt-2 mb-0">Pengguna Aktif</p>
								</div>
								<div class="col-md py-3">
									<span class="h2">1.578.991+</span>
									<p class="text-muted mt-2 mb-0">Pesanan Dikerjakan</p>
								</div>
								<div class="col-md py-3">
									<span class="h2">118+</span>
									<p class="text-muted mt-2 mb-0">Layanan</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<div class="clearfix"></div>
        <section class="section" id="features">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-credit"></i></div>
                            <h3>Pembayaran Otomatis</h3>
                            <p class="text-muted">Deposit saldo dapat diverifikasi otomatis tanpa harus konfirmasi pembayaran.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-repeat"></i></div>
                            <h3>Pembaruan</h3>
                            <p class="text-muted">Layanan selalu diperbarui agar lebih ditingkatkan dan memberi Anda pengalaman terbaik.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-refresh-cloud"></i></div>
                            <h3>Proses Otomatis</h3>
                            <p class="text-muted">Setelah anda melakukan order, secara otomatis server akan memproses pesanan anda.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-science"></i></div>
                            <h3>Layanan Berkualitas</h3>
                            <p class="text-muted">Kami menyediakan berbagai layanan terbaik untuk kebutuhan Sosial Media & Pulsa Untuk Anda.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-light"></i></div>
                            <h3>Pelayanan Bantuan</h3>
                            <p class="text-muted">Kami siap membantu Anda jika Anda mengalami kesulitan atau tidak mengerti terkait layanan yang kami sediakan.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon"><i class="pe-7s-display1"></i></div>
                            <h3>Desain Clean & Responsive</h3>
                            <p class="text-muted">Website kami dapat diakses melalui berbagai device/perangkat baik PC, tablet, maupun mobile phone.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="section" style="padding-top: 0 !important " id="produk">
			<div class="container">
				<div class="row">
					<div class="col-12">
        <h2 class="text-center mt-4 mb-3">Paket Data</h4>
						<div class="table-responsive">
							<table class="table table-bordered table-hover table-striped">
								<thead class="thead-dark">
									<tr>
										<th colspan="5">XL XTRA COMBO LITE</th>
									</tr>
								</thead>
								<thead>
									<tr>
										<th>Paket</th>
										<th>Harga</th>
										<th>Waktu</th>
										<th>S&K</th>
										<th>Deskripsi</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>COMBO LITE 1.5GB+1GB 4G+1GB Ytb 30Hr</td>
										<td>Rp27.000,-</td>
										<td>Masa Berlaku : 30 Hari</td>
										<td>Cek *123*234#<br>Jika Muncul "Terima Paket"<br>Artinya Kartu anda<br>bisa di Tembak Paket</td>
										<td>1,5GB Semua Jaringan<br>1 GB Jaringan 4G Only<br>1 GB Youtube</br></span></td>
									</tr>
									<tr>
										<td>COMBO LITE 3GB+2GB 4G+1GB Ytb 30Hr</td>
										<td>Rp38.000,-</td>
										<td>Masa Berlaku : 30 Hari</td>
										<td>Cek *123*234#<br>Jika Muncul "Terima Paket"<br>Artinya Kartu anda<br>bisa di Tembak Paket</td>
										<td>3 GB Semua Jaringan<br>2 GB Jaringan 4G Only<br>1 GB Youtube</br></span></td>
									</tr>
									<tr>
                                        <td>COMBO LITE 6GB+4GB 4G+1GB Ytb 30Hr</td>
										<td>Rp59.750,-</td>
										<td>Masa Berlaku : 30 Hari</td>
										<td>Cek *123*234#<br>Jika Muncul "Terima Paket"<br>Artinya Kartu anda<br>bisa di Tembak Paket</td>
										<td>6 GB Semua Jaringan<br>4 GB Jaringan 4G Only<br>1 GB Youtube<br>Termasuk Xtra Unlimited Turbo</br></span></td>
									</tr>
									<tr>
                                        <td>COMBO LITE 12GB+8GB 4G+1GB Ytb 30Hr</td>
										<td>Rp94.200,-</td>
										<td>Masa Berlaku : 30 Hari</td>
										<td>Cek *123*234#<br>Jika Muncul "Terima Paket"<br>Artinya Kartu anda<br>bisa di Tembak Paket</td>
										<td>12 GB Semua Jaringan<br>8 GB Jaringan 4G Only<br>1 GB Youtube<br>Termasuk Xtra Unlimited Turbo</br></span></td>
									</tr>
									<tr>
                                        <td>COMBO LITE 18GB+12GB 4G+1GB Ytb 30Hr</td>
										<td>Rp115.650,-</td>
										<td>Masa Berlaku : 30 Hari</td>
										<td>Cek *123*234#<br>Jika Muncul "Terima Paket"<br>Artinya Kartu anda<br>bisa di Tembak Paket</td>
										<td>18 GB Semua Jaringan<br>4 GB Jaringan 4G Only<br>1 GB Youtube<br>Termasuk Xtra Unlimited Turbo</br></span></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<section class="section" id="faqs">
            <div class="container">
                <div class="row text-center">
                    <div class="col-sm-12">
                        <h2 class="title">Pertanyaan Umum</h2>
                        <p class="title-alt">Berikut telah kami rangkum beberapa pertanyaan yang sering ditanyakan client terkait layanan kami.</p>
                        <div class="row text-left">
                            <div class="col-sm-6">
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>Apa Itu ansyari-pedia.com?</h4>
                                    <p><span><b>A. </b></span>ansyari-pedia.com adalah sebuah platform bisnis yang menyediakan berbagai layanan isi ulang ponsel dan social media marketing yang bergerak terutama di Indonesia. Dengan bergabung bersama kami, Anda dapat menjual produk isi ulang seperti pulsa, paket data, voucher game, e-money.dsb serta menjadi penyedia jasa social media seperti jasa penambah Followers, Likes, dll.</p>
                                </div>
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>Bagaimana Cara Mendaftar di ansyari-pedia.com?</h4>
                                    <p><span><b>A. </b></span>Silahkan kamu klik form Pendaftaran yang sudah tertera diatas.</p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>Bagaimana Cara Melakukan Deposit/Isi Saldo?</h4>
                                    <p><span><b>A. </b></span>Untuk melakukan deposit/isi saldo, Anda hanya perlu masuk terlebih dahulu ke akun Anda dan menuju halaman deposit dengan mengklik menu yang sudah tersedia. Kami menyediakan deposit melalui bank dan pulsa.</p>
                                </div>
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>Bagaimana Cara Membuat Pesanan?</h4>
                                    <p><span><b>A. </b></span>Untuk membuat pesanan sangatlah mudah, Anda hanya perlu masuk terlebih dahulu ke akun Anda dan menuju halaman pemesanan dengan mengklik menu yang sudah tersedia. Selain itu Anda juga dapat melakukan pemesanan melalui request API.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>		
        <footer class="bg-dark footer">
						<div class="col-12 text-center">
							<p class="m-b-0 font-13 copyright">Copyright &copy; 2020 Ay SMM Panel. Made with <i class="fa fa-heart text-danger"></i> by <a href="https://dunsky.id/">Dunsky</a>.</p>
						</div>
		</footer>
		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/scrollspy.min.js"></script>
		<script src="js/jquery.easing.min.js"></script>
		<script src="js/typed.js"></script>
		<script src="js/jquery.app.js"></script>
		<script>
			$(window).scroll(function() {
				var scroll = $(window).scrollTop();
				if (scroll >= 50) {
					$(".sticky").addClass("is-sticky");
				} else {
					$(".sticky").removeClass("is-sticky");
				}
			});
			$(document).ready(function() {
				$(".typed").each(function() {
					var $this = $(this);
					$this.typed({
						strings: $this.attr('data-elements').split(','),
						typeSpeed: 100, // typing speed
						backDelay: 3000 // pause before backspacing
					});
				});
			});
        </script>
	</body>
</html>